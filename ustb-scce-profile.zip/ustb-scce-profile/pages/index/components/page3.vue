<template>
<view class="content">
		<image style="width: 100%" src="../../static/logo.png" mode="widthFix"></image>
		<view class="search-box">
			<input type="text" class="search-input" v-model="keyword" placeholder="搜索姓名开头字母"/>
			<button @click="search(keyword)">搜索</button>
		</view>
		<view class="box">
			<view class="teacher-simple-card" v-for="(item, index) in teachers" :key="index" @click="goDetails(item.id)">
				<image :src="item.avatar.replace('https', 'http')" style="width: 100%; border-radius: 5px 5px; min-height: 120px; background-size: cover;"></image>
				<br />
				<view class="" style="text-align: center; margin-bottom: 8px">
					<text style="font-weight: bold;" >{{item.name}}</text>
				</view>
			</view>
		</view>
</view>
	
</template>

<script>
	import fuiIcon from "@/components/firstui/fui-icon/fui-icon.vue"
	import fuiDialog from "@/components/firstui/fui-dialog/fui-dialog.vue"


	export default{
		components:{
			fuiIcon,
			fuiDialog
		},
		data(){
			return {
				total: 0,
				teachers: [],
				totalTeachers: [],
				index: 1,
				keyword: '',		
				visible: false,
				buttons: [{
					text: '确定',
					color: '#FF2B2B'
				}],
				mytext:"教师总览",
			}
		},
		methods:{
			goDetails(id){
				uni.navigateTo({
					url:"/pages/index/detail?id=" + id,
				})
			},
			showTeachers(){
				console.log(this.teachers)
			},
			search(keyword){
				uni.request({
							url: 'http://59.110.52.50:8001/api/v1/faculty/list?initialCap=' + keyword,
							success: (res) => {
								this.teachers = res.data.data;
							},
							fail: () => {
								uni.showToast({
									title:"查找失败，请重新输入",
									duration: 2000
								})
							}
						})
				
			},
		},
		
	}
</script>

<style>
	.title {
		margin-left: 10px;
		font-size: 24px;
	}
	
	.teacher-simple-card{
		min-width: calc((100% - 40px) / 2);
		max-width: 50%;
		margin-top: 20px;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.05), 0 6px 20px 0 rgba(0, 0, 0, 0.02);
		border-radius: 5px;
		/* background-color: red; */
	}
	
	.box{
		width: 100%;
		display: flex;
		flex-wrap: wrap;
		justify-content: center;
		align-items: center;
		gap: 16px;
		/* margin-left: 8px; */
		/* margin-right: 8px; */
	}
	.search-box{
		position: sticky;
		top: 0;
		display: flex;
		flex-direction: row;
		background-color: white;
		justify-content: center;
		align-items: center;
		padding: 10px;
		gap: 4px;
	}

	.filter-btn{
		position: fixed; 
		bottom: 20px; 
		right: 20px; 
		width: 50px; 
		height: 50px; 
		border-radius: 50%;
		background-color: #007bff; 
		color: white; 
		text-align: center; 
		line-height: 50px; 
		font-size: 20px; 
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.1), 0 6px 20px 0 rgba(0, 0, 0, 0.05);
	}
	
	.search-box input{
		display: inline-block;
		/* background-color: red; */
		height: 30px;
		width: 50%;
		border-radius: 3px;
		border: 1px solid black;
		box-shadow: 1px 1px 1px black;
		text-align: center;
		background-color: white;
		padding-bottom: 2px;
	}
	
	.search-box button{
		display: inline-block;
		height: 35px;
		width: 23%;
		text-align: center;
		line-height: 2;
	}

	button {
		color: #fff;
		background: #35baf6;
		font-family: inherit;
		padding: 0.15em 1.1em;
		font-weight: 900;
		font-size: 15px;
		border: 2px solid black;
		border-radius: 0.4em;
		box-shadow: 0.1em 0.1em;
		cursor: pointer;
		}

	button:hover {
		transform: translate(-0.05em, -0.05em);
		box-shadow: 0.15em 0.15em;
	}

	button:active {
		transform: translate(0.05em, 0.05em);
		box-shadow: 0.05em 0.05em;
	}

	
</style>
