<template>
	<view class="content">
		<image style="width: 100%" src="../../static/logo.png" mode="widthFix"></image>
		<view class="title">
			<view class="classify">分类</view>
			<view class="detail">具体</view>
		</view>
		<view class="left">
			<view :class="active_flag === index ? 'left_active left_' : 'left_' "  v-for="(item, index) in leftList" :key="index" @click="getActive(index)">{{item}}</view>
		</view>
		
		<view class="right" v-if="active_flag != -1">
			
			<view :class="right_active === index ? 'right_active right_' : 'right_'" v-for="(item,index) in rightList" :key="index" @click="showRightFocus(index)">
				{{item.content}}
			</view>
			
			
		</view>
		
	</view>
</template>

<script>
	export default{
		data(){
			return{
				leftList:["系所"],
				active_flag: -1,
				right_active: -1,
				rightList: [],
				showList: [],
				total:"",
			}
		},
		methods:{
			getActive(index){
				this.active_flag = this.active_flag === index ? -1 : index;
				uni.request({
					url:"http://59.110.52.50:8001/api/v1/departments",
					success: (res) => {
						this.rightList = res.data.data.slice(0, res.data.data.length - 2);
					}
				})
			},
			showRightFocus(index){
				this.showList = [];
				this.right_active = index;
				this.total = 0;
				var target = this.rightList[index].content;
				console.log(target);
				for(var idx = 1; idx <= 6; idx++){
					var tmp = [];
					uni.request({
						url:"http://59.110.52.50:8001/api/v1/faculty/list?index=" + idx,
						success: (res) => {
							tmp = res.data.data;
							var len = tmp.length;
							for(var j = 0; j < len; j++){
								if(tmp[j].department.indexOf(target) != -1){
									this.showList.push(tmp[j]);
								}
							}
						}
					})
				}
				// 更新主页显示列表
				// 回传给父组件参数
				uni.$emit('upDate', this.showList);
				
				uni.navigateBack();
			}
		},
		onLoad() {
		}
	}
	
</script>

<style>
	.left{
		text-align: center;
		float: left;
		width: 15%;
		margin-top: 10px;
	}
	
	.left_{
		border-radius: 10px;
		border: 1px solid black;
		background-color: white;
		margin-bottom: 10px;
		height: 20px;
		text-align: center;
		line-height: 1;
		
	}
	
	.left_active{
		color: white;
		background-color: grey;
		
	}
	
	.content{
		width: 100%;
		height: 700px;
		/* background-color: green; */
	}
	
	.right{
		float: right;
		text-align: center;
		margin-top: 10px;
		/* background-color: yellow; */

	}
		
	.right_{
		border: 1px solid black;
		background-color: white;
		height: 20px;
		text-align: center;
		line-height: 20px;
		margin-bottom: 10px;
		display: block;
		border-radius: 10px;
	}
	
	.right_active{
		background-color: #00aaff;
	}
	
	.title{
		margin-top: 3px;
		text-align: center;
		width: 100%;
		/* background-color: red; */
	}
	
	.title .classify{
		width: 15%;
		display: inline-block;
	}
	
	.title .detail{
		width: 85%;
		display: inline-block;
	}
	
	
	
</style>