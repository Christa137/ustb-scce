<template>
	<image style="width: 100%;" src="../../static/logo.png" mode="widthFix"></image>
	
	<view style="margin-left: 8px; margin-right: 8px;">
		
		<view class="first">
			<image style="width: 40%; border-radius: 5px; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.1), 0 6px 20px 0 rgba(0, 0, 0, 0.05);" :src="teacher.avatar.replace('https', 'http')" mode="widthFix"></image>
			
			
			<view>
				<text style="font-size: 24px; font-weight: bold; margin-right: 3px;">{{teacher.name}} </text>
				<!-- <text class="email" style="color: #ffc107;">@{{teacher.officeLocation}}</text> -->
				<!-- <text>职称: <text class="email">{{teacher.title.join(',')}} </text> </text> <br/> -->
				<br/>
				<div style="display: flex; align-items: center; margin-top: 8px;">
					<fui-icon name="my" size="40" style="margin-right: 8px;"></fui-icon>

					<span  v-for="i in teacher.title" >
						<view v-if="i != '否'" style="font-size: 12px; background-color: #1769aa; margin-right: 3px; border-radius: 5px; color: #fff; padding: 3px;">{{i}}</view>
					</span>
				</div>
				
				<div style="display: flex; align-items: center; margin-top: 8px;">
					<fui-icon name="mail" size="40" style="margin-right: 8px;"></fui-icon>
				
					<span style="font-size: 12px; ">
						{{teacher.email}}
					</span>
				</div>
				
				<div style="margin-top: 8px; display: flex; align-items: flex-start;">
					<fui-icon name="warehouse" size="40" style="margin-right: 8px; display: inline-block;"></fui-icon>
					<div style="display: flex; flex-direction: column; font-size: 12px; gap: 2px;">
						<span v-for="i in teacher.department" style="margin-right: 3px; border-radius: 5px; padding: 3px; ">{{i}}</span>
					</div>
				</div>
			

			</view>
		</view>
		
		<div style="margin-top: 16px;">
			<!-- <div class="subcard">
				<div class="sub-title-head" style="display: flex; align-items: center;">
					<fui-icon name="comment" size="40" style="margin-right: 8px; display: inline-block;"></fui-icon>
					<text class="subtitle">本科生课程</text>
				</div>
				
				<div class="divider"></div>

				<text class="article">{{teacher.undergraduateCourses}}</text>
			</div>
			
			<div class="subcard">
				<div class="sub-title-head" style="display: flex; align-items: center;">
					<fui-icon name="comment" size="40" style="margin-right: 8px; display: inline-block;"></fui-icon>
					<text class="subtitle">研究生课程</text>
				</div>
				<div class="divider"></div>
				<text class="article">  {{teacher.researchDirections}} </text>
			</div>
			 -->
			<div class="subcard">
				<div class="sub-title-head" style="display: flex; align-items: center;">
					<fui-icon name="info" size="40" style="margin-right: 8px; display: inline-block;"></fui-icon>
					<text class="subtitle">简介</text>
				</div>
				<div class="divider"></div>
				<text class="article">{{this.escapeHtml(teacher.resume)}}</text>
			</div>
			
			<!-- <div class="subcard">
				<div class="sub-title-head" style="display: flex; align-items: center;">
					<fui-icon name="order" size="40" style="margin-right: 8px; display: inline-block;"></fui-icon>
					<text class="subtitle">论文</text>
				</div>
				<div class="divider"></div>
				<text class='article' style="font-family:'Times New Roman', Times, serif;">{{this.escapeHtml(teacher.papers.join('\n'))}} </text>
				<div v-for="pap in teacher.papers" style="overflow: auto;">
					<span>{{pap}}</span>
				</div>
			</div>
			
			<div class="subcard">
				<div class="sub-title-head" style="display: flex; align-items: center;">
					<fui-icon name="face" size="40" style="margin-right: 8px; display: inline-block;"></fui-icon>
					<text class="subtitle">科研业绩</text>
				</div>
				<div class="divider"></div>
				<text class="article">{{this.escapeHtml(teacher.performance.join('\n'))}}</text>
			</div>
			
			<div class="subcard">
				<div class="sub-title-head" style="display: flex; align-items: center;">
					<fui-icon name="star" size="40" style="margin-right: 8px; display: inline-block;"></fui-icon>
					<text class="subtitle">获奖</text>
				</div>
				<div class="divider"></div>
				<text class="article">  {{this.escapeHtml(teacher.rewards.join('\n'))}} </text>
			</div>
			 -->
		</div>
		
		
	</view>
</template>

<script>
	import fuiIcon from "@/components/firstui/fui-icon/fui-icon.vue"
	export default{
		components:{
			fuiIcon
		},
		data(){
			return{
				teacher: {},
			}
		},
		
		onLoad(option) {
			console.log("获取到的id = " + option.id);
			uni.request({
				url:"http://59.110.52.50:8001/api/v1/faculty/detail/" + option.id,
				success: (res) => {
					this.teacher = res.data.data;
					
					// handle paper list. &ldquo &rdquo
					this.teacher.papers = this.teacher.papers.map((item) => {
						// return item.replace(/\n/g, '');
						return item.replace(/\n/g, '').replace(/&ldquo;/g, '“').replace(/&rdquo;/g, '”');

					}).filter((item) => {
						return item != '';
					});

					this.teacher.performance = this.teacher.performance.map((item) => {
						// return item.replace(/\n/g, '');
						return item.replace(/\n/g, '').replace(/&ldquo;/g, '“').replace(/&rdquo;/g, '”');

					}).filter((item) => {
						return item != '';
					});

					this.teacher.rewards = this.teacher.rewards.map((item) => {
						// return item.replace(/\n/g, '');
						return item.replace(/\n/g, '').replace(/&ldquo;/g, '“').replace(/&rdquo;/g, '”');

					}).filter((item) => {
						return item != '';
					});

					console.log(this.teacher)
				},
				fail: () => {
					console.log("查找失败");
				}
			})
		},
		
		methods:{
			escapeHtml(str) {
			    var arrEntities={'lt':'<','gt':'>','nbsp':' ','amp':'&','quot':'"' };
			    return str.replace(/&(lt|gt|nbsp|amp|quot|);/ig,function(all,t){return arrEntities[t];});
			}
		}
		
		
	}
	
	
</script>

<style scoped>
	.first {
		display: flex;
		gap: 8px;
		justify-content: start;
		margin-top: 8px;
	}
	
	.divider {
	  width: 100%; /* 设置分隔线的宽度 */
	  height: 1px; /* 设置分隔线的高度 */
	  background-color: #eee; /* 设置分隔线的颜色 */
	  margin: 6px 0; /* 设置分隔线上下的外边距 */
	}
	
	.subcard {
		margin-bottom: 12px;
		padding: 10px;
		border-radius: 5px; 
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.05), 0 6px 20px 0 rgba(0, 0, 0, 0.02);
	}
	.subtitle{
		margin-bottom: 4px;
		font-size: 18px;
	}
	
	.sub-title-head {
		
	}
	
	.left{
		margin-top: 30px;
		margin-left: 10px;
		width: 40%;
		/* background-color: yellow; */
		border-radius: 5px;
		display: block;
		float: left;
		
	}

	.aside{
		margin-top: 20px;
		margin-left: 20px;
		display: inline-block;
		width: 60%;
		height: 100px;
		/* background-color: yellow; */
		line-height: 2;
	}
	
	.footer{
		width: 100%;
		margin: 10px;
		clear: both;
		margin-left: 5px;
		line-height: 2;
		/* background-color: red; */
	}

	.email{
		font-weight: 400;
		font-size: 30rpx;
		white-space:pre-line;
	}
	
	.article{
		font-weight: 400;
		font-size: 30rpx;
		display: block;
		overflow: auto;
		margin-top: 8px;
		letter-spacing: 1.2px;
		white-space:pre-line;
		line-height: 1.5;
		max-height: 350px;
		overflow: scroll;

	}

	text{
		font-weight: bold;
		font-size: 35rpx;
	}


</style>