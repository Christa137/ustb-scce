<template>
<view class="content">
		<image style="width: 100%" src="../../static/logo.png" mode="widthFix"></image>
		<view class="search-box">
			<input type="text" class="search-input" v-model="keyword" placeholder="搜索教师"/>
			<button @click="search(keyword)">搜索</button>
			<button @click="toFilter">筛选</button>
		</view>
		
		<div class="card">
		  <div class="item item--1" @click="toPage1">
		   <span class="quantity"> 
				系所 <br/>检索 <br/>
			</span>
		  </div>
		  <div class="item item--2" @click="toPage2">
		   <span class="quantity"> 
				职称 <br/>检索 <br/>
		   </span>
		  </div>
		  <div class="item item--3" @click="toPage3">
		    <span class="quantity"> 
				姓名 <br/>检索 <br/>
			 </span>
		  </div>
		  <div class="item item--4" @click="toPage4">
		    <span class="quantity"> 
				 <br/>教师 <br/>总览 <br/>
			 </span>
		    <!-- <span class="text text--4"> Animations </span> -->
		  </div>
		</div>
		<!-- <view class="title" style="font-weight: bold; margin-top: 20px;" v-if="freshBottom">{{mytext}} ({{ total }}名)</view>
		<view class="title" style="font-weight: bold; margin-top: 20px;" v-else>{{mytext}}</view>
		<view class="box">
			<view class="teacher-simple-card" v-for="(item, index) in teachers" :key="index" @click="goDetails(item.id)">
				<image :src="item.avatar.replace('https', 'http')" style="width: 100%; border-radius: 5px 5px; min-height: 120px; background-size: cover;"></image>
				<br />
				<view class="" style="text-align: center; margin-bottom: 8px">
					<text style="font-weight: bold;" >{{item.name}}</text>
				</view>
			</view>
		</view>

		<view>
			<view class="filter-btn" style="" @click="onFilterBtnClick()">
				<fui-icon name="search" size="40" color="#fff"></fui-icon>
			
			</view>
		</view>

		<fui-dialog :show="visible" title="我是标题" content="我是自定义的对话框！" :buttons="buttons" @click="onTap">
		
		</fui-dialog> -->
</view>
	
</template>

<script>
	import fuiIcon from "@/components/firstui/fui-icon/fui-icon.vue"
	import fuiDialog from "@/components/firstui/fui-dialog/fui-dialog.vue"


	export default{
		components:{
			fuiIcon,
			fuiDialog
		},
		data(){
			return {
				total: 0,
				teachers: [],
				totalTeachers: [],
				index: 1,
				keyword: '',		
				visible: false,
				buttons: [{
					text: '确定',
					color: '#FF2B2B'
				}],
				mytext:"教师总览",
				freshBottom: true
			}
		},
		methods:{
			goDetails(id){
				uni.navigateTo({
					url:"/pages/index/detail?id=" + id,
				})
			},
			toPage1(){
				uni.navigateTo({
					url:"/pages/index/components/page1",
				})
			},
			toPage2(){
				uni.navigateTo({
					url:"/pages/index/components/page2",
				})
			},
			toPage3(){
				uni.navigateTo({
					url:"/pages/index/components/page3",
				})
			},
			toPage4(){
				uni.navigateTo({
					url:"/pages/index/components/page4",
				})
			},
			showTeachers(){
				console.log(this.teachers)
			},
			search(keyword){
				if(keyword === '') return;
				uni.request({
					url: 'http://59.110.52.50:8001/api/v1/faculty/list?name=' + keyword,
					success: (res) => {
						var id = res.data.data[0].id;
						uni.navigateTo({
							url:"/pages/index/detail?id=" + id,
						})
					},
					fail: () => {
						uni.showToast({
							title:"查找失败，请重新输入",
							duration: 2000
						})
					}
				})
			},
			toFilter() {
				uni.navigateTo({
					url:"/pages/index/filter"
				})
			}
			
		},
		onLoad(){
			console.log("拉取数据")
			uni.request({
				url:"http://59.110.52.50:8001/api/v1/faculty/list?index=" + "1",
				success: (res) => {
					this.total = res.data.total;
					this.teachers = res.data.data;
					this.totalTeachers = res.data.data;
				}
			})
			
		},
		onPullDownRefresh(){
			this.teachers = this.totalTeachers;
			this.freshBottom = true;
		},
		
		onReachBottom() {
			this.index++;
			if(this.index > 6){
				return;
			}
			if(this.freshBottom){
				uni.request({
					url:"http://59.110.52.50:8001/api/v1/faculty/list?index=" + this.index,
					success: (res) => {
						console.log("数据获取成功", res.data.data);
						
						if(this.index == 6) this.teachers = [...this.teachers, ...res.data.data.slice[0, res.data.data.length]];
						else this.teachers = [...this.teachers, ...res.data.data];
					}
				})
			}
		},
		
		
		created() {
			uni.$on('upDate', (res)=>{
				this.teachers = res;
				this.freshBottom = false;
				this.mytext = "筛选结果";
			})
		},
		
		onFilterBtnClick() {
			
		}
	}
</script>

<style>
	.title {
		margin-left: 10px;
		font-size: 24px;
	}
	
	.teacher-simple-card{
		min-width: calc((100% - 40px) / 2);
		max-width: 50%;
		margin-top: 20px;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.05), 0 6px 20px 0 rgba(0, 0, 0, 0.02);
		border-radius: 5px;
		/* background-color: red; */
	}
	
	.box{
		width: 100%;
		display: flex;
		flex-wrap: wrap;
		justify-content: center;
		align-items: center;
		gap: 16px;
		/* margin-left: 8px; */
		/* margin-right: 8px; */
	}
	.search-box{
		position: sticky;
		top: 0;
		display: flex;
		flex-direction: row;
		background-color: white;
		justify-content: center;
		align-items: center;
		padding: 10px;
		gap: 4px;
	}

	.filter-btn{
		position: fixed; 
		bottom: 20px; 
		right: 20px; 
		width: 50px; 
		height: 50px; 
		border-radius: 50%;
		background-color: #007bff; 
		color: white; 
		text-align: center; 
		line-height: 50px; 
		font-size: 20px; 
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.1), 0 6px 20px 0 rgba(0, 0, 0, 0.05);
	}
	
	.search-box input{
		display: inline-block;
		/* background-color: red; */
		height: 30px;
		width: 50%;
		border-radius: 3px;
		border: 1px solid black;
		box-shadow: 1px 1px 1px black;
		text-align: center;
		background-color: white;
		padding-bottom: 2px;
	}
	
	.search-box button{
		display: inline-block;
		height: 35px;
		width: 23%;
		text-align: center;
		line-height: 2;
	}

	button {
		color: #fff;
		background: #35baf6;
		font-family: inherit;
		padding: 0.15em 1.1em;
		font-weight: 900;
		font-size: 15px;
		border: 2px solid black;
		border-radius: 0.4em;
		box-shadow: 0.1em 0.1em;
		cursor: pointer;
		}

	button:hover {
		transform: translate(-0.05em, -0.05em);
		box-shadow: 0.15em 0.15em;
	}

	button:active {
		transform: translate(0.05em, 0.05em);
		box-shadow: 0.05em 0.05em;
	}
	
	.card {
	  /* width: 190px;
	  height: 254px; */
	  color: white;
	  display: grid;
	  grid-template-columns: 1fr 1fr;
	  grid-template-rows: 1fr 1fr;
	  gap: 5px;
	  overflow: visible;
	  margin-left: 15%;
	  margin-top: 20px;
	  margin-bottom: 20px;
	  width: 250px;
	  height: 330px;
	}
	
	.card .item {
	  border-radius: 10px;
	  width: 100%;
	  height: 100%;
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  justify-content: center;
	}
	
	.item:hover {
	  /* transform: scale(1.37); */
	  transition: all 1s ease-in-out;
	  /* rotate: 360deg; */
	}
	
	.item svg {
	  width: 40px;
	  height: 40px;
	  margin-bottom: 7px;
	}
	
	.item--1 {
	  background: #c7c7ff;
	}
	
	.item--2 {
	  background: #ffd8be;
	}
	
	.item--3 {
	  background: #a9ecbf;
	}
	
	.item--4 {
	  background: #f3bbe1;
	}
	
	.quantity {
	  font-size: 25px;
	  font-weight: 600;
	}
	
	.text {
	  font-size: 12px;
	  font-family: inherit;
	  font-weight: 600;
	}
	
	.text--1 {
	  color: rgba(149,149,255,1);
	}
	
	.text--2 {
	  color: rgba(252,161,71,1);
	}
	
	.text--3 {
	  color: rgba(66,193,110,1);
	}
	
	.text--4 {
	  color: rgba(220,91,183,1);
	}
	
</style>
